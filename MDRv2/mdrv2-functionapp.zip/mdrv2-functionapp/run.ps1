# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"

# Azure Tenant ID
$tenantId = $($env:Difenda_tenantId)

# App Registration ID (Client ID)
$clientId = $($env:Difenda_clientId)

# App Registration Secret
$appSecret = $($env:Difenda_appSecret)

# Workspace ID
$CustomerId = $($env:Difenda_workspaceId)

# Workspace Primary Key
$SharedKey = $($env:Difenda_workspaceKey)

# Computer Name
$ComputerName = "Difenda"

Write-Host "Tenant Id     : $tenantId"
Write-Host "Client Id     : $clientId"
Write-Host "Client Secret : ***"
Write-Host "Workspace Id  : $CustomerId"
Write-Host "Workspace Key : ***"

$resourceAppIdUri = 'https://api.securitycenter.microsoft.com'
$url = "https://api.securitycenter.microsoft.com/api/advancedqueries/run"

# Specify the name of the record type that you'll be creating
$LogType = "MDRv2SecurityAlert"
$errorType = "MDRv2Errors"

# You can use an optional field to specify the timestamp from the data. If the time field is not specified, Azure Monitor assumes the time is the message ingestion time
$TimeStampField = ""

$detectionsLocation = "C:\home\MDRv2Detections"
Write-Host "Reading detection definitions from $detectionsLocation"

Function Build-Signature ($customerId, $sharedKey, $date, $contentLength, $method, $contentType, $resource)
{
    $xHeaders = "x-ms-date:" + $date
    $stringToHash = $method + "`n" + $contentLength + "`n" + $contentType + "`n" + $xHeaders + "`n" + $resource

    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes = [Convert]::FromBase64String($sharedKey)

    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash = [Convert]::ToBase64String($calculatedHash)
    $authorization = 'SharedKey {0}:{1}' -f $customerId,$encodedHash
    return $authorization
}

Function Post-LogAnalyticsData($customerId, $sharedKey, $body, $logType)
{
    $method = "POST"
    $contentType = "application/json"
    $resource = "/api/logs"
    $rfc1123date = [DateTime]::UtcNow.ToString("r")
    $contentLength = $body.Length
    $signature = Build-Signature `
        -customerId $customerId `
        -sharedKey $sharedKey `
        -date $rfc1123date `
        -contentLength $contentLength `
        -method $method `
        -contentType $contentType `
        -resource $resource
    $uri = "https://" + $customerId + ".ods.opinsights.azure.com" + $resource + "?api-version=2016-04-01"

    $headers = @{
        "Authorization" = $signature;
        "Log-Type" = $logType;
        "x-ms-date" = $rfc1123date;
        "time-generated-field" = $TimeStampField;
    }

    try {
        $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $body -UseBasicParsing -ErrorAction Stop
        return $response.StatusCode
    }
    catch {
        # $ErrorMessage = $_.Exception.Message
        $ErrorMessage = $_.ErrorDetails.Message
        return $ErrorMessage
    }
}

$objectCount = Get-ChildItem -Path $detectionsLocation -Recurse -Include "*.yaml" | Measure-Object

if ($objectCount.Count -gt 0) {
    $continue = $true
    Write-Host "Reading " $objectCount.Count "detection definition files ..."
}
else {
    $continue = $false
    Write-Warning "No definition files found in $detectionsLocation"
}

if ($continue) {
    try {
        $definitionFiles = Get-ChildItem -Path $detectionsLocation -Recurse -Include "*.yaml" -ErrorAction Stop
    }
    catch {
        $continue = $false
        $ErrorMessage = $_.Exception.Message
        Write-Error "Error reading definition files from $detectionsLocation. $ErrorMessage"
    }
}

if ($continue) {

    $processed = 0

    $oAuthUri = "https://login.microsoftonline.com/$tenantId/oauth2/token"
    $body = [Ordered] @{
        resource = "$resourceAppIdUri"
        client_id = "$clientId"
        client_secret = "$appSecret"
        grant_type = 'client_credentials'
    }

    try {
        $response = Invoke-RestMethod -Method Post -Uri $oAuthUri -Body $body -ErrorAction Stop
    }
    catch {
        $continue = $false
        $ErrorMessage = $_.Exception.Message
        Write-Error "Error obtaining access token. $ErrorMessage"
    }

    if ($continue) {

        $aadToken = $response.access_token

        foreach ($file in $definitionFiles) {

$json = @"
"@
            $continue = $true
            $ErrorMessage = $null
            $errorDetails = $null
            $returnCode = $null
            $processed = $processed + 1
            $fileName = ( Split-Path $file -leaf )
            Write-Host "----------------------------------"
            Write-Host "Reading detection definition from: $fileName"
    
            try {
                $definition = ( Get-Content -Path $file -ErrorAction Stop | ConvertFrom-Yaml )
            }
            catch {
                $continue = $false
                $errorDetails = $_.ErrorDetails.Message
                $ErrorMessage = $_.Exception.Message
                Write-Warning "  ==> Error reading detection definition from $fileName. $ErrorMessage"
                # Write-Host $errorDetails -ForegroundColor Red
            }

            if ($continue) {
                Write-Host "Done."

                $query = $definition.query

                $headers = @{ 
                    'Content-Type' = 'application/json'
                    Accept = 'application/json'
                    Authorization = "Bearer $aadToken" 
                }

                $body = ConvertTo-Json -InputObject @{ 'Query' = $query }

                try {
                    $webResponse = Invoke-WebRequest -Method Post -Uri $url -Headers $headers -Body $body -ErrorAction Stop
                }
                catch {
                    $continue = $false
                    $errorDetails = $_.ErrorDetails.Message
                    $ErrorMessage = $_.Exception.Message
                    Write-Warning "  ==> Error running detection. $ErrorMessage"
                    # Write-Host $errorDetails -ForegroundColor Red
                }

                if ($continue) {

                    $response = $webResponse | ConvertFrom-Json
                    $results = $response.Results

                    if ($results -ne $null) {

                        $matchesCount = $results.Count
                        Write-Warning "  ==> $matchesCount matches found. Writing detection results ... "

                            foreach ($i in 1..$results.Count) {

                                $index = $i - 1
    
                                # Creating a timestamp field for the Alert
                                $TimeStampDate = [DateTime]::UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.000Z")

                                # Adding contectual information to the Alert
                                $detectionId = $definition.id
                                $detectionDesc = $definition.description | ConvertTo-Json
                                $detectionName = $definition.name | ConvertTo-Json
                                $detectionTactics = $definition.tactics | ConvertTo-Json
                                $detectionSeverity = $definition.severity | ConvertTo-Json
                                $detectionTags = $definition.tags | ConvertTo-Json
                                $detectionTechniques = $definition.relevantTechniques | ConvertTo-Json

                                # Formatting the results to be added to the alert
                                # $resultsJson = $response.Results | ConvertTo-Json
                                # $schemaJson = $response.Schema | ConvertTo-Json
                                $resultsJson = $results[$index] | ConvertTo-Json
                                $schemaJson = $results[$index] | ConvertTo-Json

$json=@"
    [
        {
        "Computer": "$ComputerName",
        "Timestamp": "$TimeStampDate",
        "Name": $detectionName,
        "Description": $detectionDesc,
        "Tactics": $detectionTactics,
        "Techniques": $detectionTechniques,
        "Severity": $detectionSeverity,
        "Tags": $detectionTags,
        "NumberValue": $processed,
        "GUIDValue": "$detectionId",
        "ResultsData": $resultsJson,
        "ResultsSchema": $schemaJson
        }
    ]
"@

                                Write-Warning "  ==> Writing matched result ($i) ... "
                                $returnCode = Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json)) -logType $logType

                                if ($returnCode -eq 200) { Write-Host "Message written in $LogType table" }
                                else { Write-Warning "  ==> Could not add entry in $LogType table" }
    
                            }

                    }
                    else {
                        Write-Host "  ==> Good news. No results!"
                    }   
                }
            }

            if ($ErrorMessage -ne $null) {

                $messageJson = $ErrorMessage | ConvertTo-Json
                
                # Creating a timestamp field for the Alert
                $TimeStampDate = [DateTime]::UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.000Z")

                # Adding contectual information to the Alert
                $detectionId = $definition.id
                $detectionDesc = $definition.description | ConvertTo-Json
                $detectionName = $definition.name | ConvertTo-Json
                $detectionTactics = $definition.tactics | ConvertTo-Json
                $detectionSeverity = $definition.severity | ConvertTo-Json
                $detectionTags = $definition.tags | ConvertTo-Json
                $detectionTechniques = $definition.relevantTechniques | ConvertTo-Json
                $detectionQuery = $definition.query  | ConvertTo-Json

$json=@"
    [
        {
        "Computer": "$ComputerName",
        "Description": $detectionDesc,
        "ErrorMessage": $messageJson,
        "ErrorDetails": $errorDetails,
        "GUIDValue": "$detectionId",
        "Name": $detectionName,
        "Query": $detectionQuery,
        "RulePosition": $processed,
        "Severity": $detectionSeverity,
        "Timestamp": "$TimeStampDate",
        "Tactics": $detectionTactics,
        "Techniques": $detectionTechniques,
        "Tags": $detectionTags
        }
    ]
"@

                Write-Warning "  ==> Error processing detection query. Writing error message ... "
                $returnCode = Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json)) -logType $errorType

                if ($returnCode -eq 200) { Write-Host "Alert data written in $errorType table" }
                else { Write-Warning "  ==> Could not add entry in $errorType table. $returnCode. $ErrorMessage." }

            }
            
            $totalCount = $objectCount.Count
            Write-Host "  ==> Finished detection $processed of $totalCount. Pausing for 3 seconds ... "
            Start-Sleep -Seconds 3
            Write-Host "  ==> Resuming execution."

        }
    }
}
